-- 0002 — Varsayılan SMS şablonları (kullanıcı Ayarlar/SMS > Şablonlar'dan değiştirebilir)
INSERT OR IGNORE INTO sms_templates(name, body, kind) VALUES
 ('Geciken taksit', 'Sayın {veli_adi}, {ogrenci_adi} isimli öğrencinizin {taksit_tarihi} vadeli {kalan_tutar} TL tutarındaki ödemesi gecikmiştir. Bilginize sunarız. {kurum_adi}', 'overdue'),
 ('Üyelik bitiş hatırlatması', 'Sayın {veli_adi}, {ogrenci_adi} isimli öğrencinizin çalışma salonu üyeliği {bitis_tarihi} tarihinde sona erecektir. Yenileme için kurumumuza başvurabilirsiniz. {kurum_adi}', 'expiry'),
 ('Genel duyuru', 'Sayın {veli_adi}, ', 'general');
CREATE INDEX IF NOT EXISTS ix_sms_batch ON sms_logs(batch_id);
