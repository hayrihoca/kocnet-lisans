-- 0004 — Kullanıcı isteği (13.11.2026):
--  * Bekleme listesi ayrı bir kayıt defteri: kayıtlı olmayan aday da yazılır (ad soyad + telefon + sınav türü).
--    Kayıtlar silinmez; yerleşen/çıkarılan adaylar geçmişte kalır. İletişim (arandı) bilgisi tutulur.
--  * Öğrencide sınav türü (YKS, LGS, KPSS ...).
--  * Silinen öğrenci kalıcı silinmez: "Silinenler" arşivine gider (deleted_at), geri yüklenebilir.

ALTER TABLE students ADD COLUMN exam_type TEXT;
ALTER TABLE students ADD COLUMN deleted_at TEXT;
ALTER TABLE students ADD COLUMN deleted_by INTEGER REFERENCES users(id) ON DELETE RESTRICT;
ALTER TABLE students ADD COLUMN delete_reason TEXT;
CREATE INDEX ix_students_deleted ON students(deleted_at);

CREATE TABLE waiting_list_new (
    id           INTEGER PRIMARY KEY,
    student_id   INTEGER REFERENCES students(id) ON DELETE RESTRICT,
    full_name    TEXT,
    phone        TEXT    CHECK (phone IS NULL OR (length(phone) = 10 AND phone NOT GLOB '*[^0-9]*')),
    exam_type    TEXT,
    hall_id      INTEGER REFERENCES halls(id) ON DELETE RESTRICT,
    applied_on   TEXT    NOT NULL CHECK (date(applied_on) IS applied_on),
    priority     INTEGER NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
    note         TEXT,
    status       TEXT    NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting','placed','cancelled')),
    closed_at    TEXT,
    contacted_at TEXT,
    contact_note TEXT,
    created_by   INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (student_id IS NOT NULL OR length(trim(COALESCE(full_name, ''))) > 0)
);
INSERT INTO waiting_list_new(id, student_id, hall_id, applied_on, priority, note, status, closed_at, created_by, created_at)
    SELECT id, student_id, hall_id, applied_on, priority, note, status, closed_at, created_by, created_at FROM waiting_list;
DROP TABLE waiting_list;
ALTER TABLE waiting_list_new RENAME TO waiting_list;
CREATE UNIQUE INDEX uq_waiting_student ON waiting_list(student_id) WHERE status = 'waiting' AND student_id IS NOT NULL;
CREATE INDEX ix_waiting_hall ON waiting_list(hall_id, status);
CREATE INDEX ix_waiting_status ON waiting_list(status, applied_on);
