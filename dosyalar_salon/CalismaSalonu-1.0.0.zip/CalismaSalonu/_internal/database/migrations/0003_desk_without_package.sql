-- 0003 — Paketsiz masa ataması (kullanıcı isteği 2026-11-13): bazı öğrenciler yalnız salona kayıt için gelir.
-- S1 kuralı (masa için aktif/dondurulmuş üyelik şart) kaldırıldı; diğer masa kuralları aynen korunur.
DROP TRIGGER IF EXISTS trg_desk_assign_rules;
CREATE TRIGGER trg_desk_assign_rules BEFORE INSERT ON desk_assignments
WHEN NEW.end_date IS NULL
BEGIN
    SELECT RAISE(ABORT, 'Bu masa silinmiş ya da kullanım dışı.')
     WHERE EXISTS (SELECT 1 FROM desks d WHERE d.id = NEW.desk_id AND (d.is_deleted = 1 OR d.state = 'out_of_service'));
    SELECT RAISE(ABORT, 'Bu masa başka bir öğrenciye rezerve edilmiş.')
     WHERE EXISTS (SELECT 1 FROM desks d WHERE d.id = NEW.desk_id AND d.state = 'reserved'
                      AND d.reserved_for_student_id IS NOT NEW.student_id);
    SELECT RAISE(ABORT, 'Pasif öğrenciye masa atanamaz.')
     WHERE (SELECT status FROM students WHERE id = NEW.student_id) IS NOT 'active';
END;
