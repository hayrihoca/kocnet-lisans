-- 0001_initial — Çalışma Salonu Yönetim Sistemi ilk şema (TASARIM.md 1.0, 12.11.2026)
-- Para: INTEGER kuruş. Tarih: TEXT 'YYYY-MM-DD'. Zaman: TEXT 'YYYY-MM-DD HH:MM:SS' yerel.
-- Finansal kayıtlar silinmez/değiştirilmez: yalnız iptal (ters kayıt). Kurallar hem burada hem servislerde.

-- ============================================================ KULLANICI VE GÜVENLİK
CREATE TABLE users (
    id              INTEGER PRIMARY KEY,
    username        TEXT    NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(username)) >= 3),
    full_name       TEXT    NOT NULL CHECK (length(trim(full_name)) > 0),
    password_hash   TEXT    NOT NULL CHECK (password_hash LIKE 'pbkdf2_sha256$%$%$%'),
    role            TEXT    NOT NULL CHECK (role IN ('admin','staff')),
    is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    failed_attempts INTEGER NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
    locked_until    TEXT,
    last_login_at   TEXT,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE audit_logs (
    id          INTEGER PRIMARY KEY,
    user_id     INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    action      TEXT    NOT NULL,
    entity      TEXT    NOT NULL,
    entity_id   INTEGER,
    before_json TEXT,
    after_json  TEXT,
    reason      TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_audit_entity ON audit_logs(entity, entity_id);
CREATE INDEX ix_audit_created ON audit_logs(created_at);

CREATE TRIGGER trg_audit_no_update BEFORE UPDATE ON audit_logs
BEGIN SELECT RAISE(ABORT, 'Denetim kaydı değiştirilemez.'); END;
CREATE TRIGGER trg_audit_no_delete BEFORE DELETE ON audit_logs
BEGIN SELECT RAISE(ABORT, 'Denetim kaydı silinemez.'); END;

-- ============================================================ ÖĞRENCİ
CREATE TABLE students (
    id             INTEGER PRIMARY KEY,
    student_no     TEXT    NOT NULL UNIQUE CHECK (length(trim(student_no)) > 0),
    first_name     TEXT    NOT NULL CHECK (length(trim(first_name)) > 0),
    last_name      TEXT    NOT NULL CHECK (length(trim(last_name)) > 0),
    phone          TEXT    CHECK (phone IS NULL OR (length(phone) = 10 AND phone NOT GLOB '*[^0-9]*')),
    guardian_name  TEXT,
    guardian_phone TEXT    CHECK (guardian_phone IS NULL OR (length(guardian_phone) = 10 AND guardian_phone NOT GLOB '*[^0-9]*')),
    registered_on  TEXT    NOT NULL CHECK (date(registered_on) IS registered_on),
    status         TEXT    NOT NULL DEFAULT 'active' CHECK (status IN ('active','passive')),
    note           TEXT,
    search_key     TEXT    NOT NULL,
    created_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at     TEXT
);
CREATE INDEX ix_students_search ON students(search_key);
CREATE INDEX ix_students_phone ON students(phone);
CREATE INDEX ix_students_gphone ON students(guardian_phone);
CREATE INDEX ix_students_status ON students(status);

CREATE TABLE student_notes (
    id         INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    note       TEXT    NOT NULL CHECK (length(trim(note)) > 0),
    created_by INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_student_notes_student ON student_notes(student_id);

-- ============================================================ SALON VE MASA
CREATE TABLE halls (
    id           INTEGER PRIMARY KEY,
    name         TEXT    NOT NULL UNIQUE CHECK (length(trim(name)) > 0),
    floor        TEXT,
    description  TEXT,
    capacity     INTEGER NOT NULL DEFAULT 0 CHECK (capacity >= 0),
    is_active    INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    grid_columns INTEGER NOT NULL DEFAULT 6 CHECK (grid_columns BETWEEN 1 AND 30),
    sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE desks (
    id                      INTEGER PRIMARY KEY,
    hall_id                 INTEGER NOT NULL REFERENCES halls(id) ON DELETE RESTRICT,
    label                   TEXT    NOT NULL CHECK (length(trim(label)) BETWEEN 1 AND 12),
    x                       INTEGER NOT NULL CHECK (x >= 0),
    y                       INTEGER NOT NULL CHECK (y >= 0),
    width                   INTEGER NOT NULL DEFAULT 2 CHECK (width BETWEEN 1 AND 10),
    height                  INTEGER NOT NULL DEFAULT 2 CHECK (height BETWEEN 1 AND 10),
    state                   TEXT    NOT NULL DEFAULT 'available' CHECK (state IN ('available','reserved','out_of_service')),
    reserved_for_student_id INTEGER REFERENCES students(id) ON DELETE RESTRICT,
    reserved_until          TEXT    CHECK (reserved_until IS NULL OR date(reserved_until) IS reserved_until),
    is_deleted              INTEGER NOT NULL DEFAULT 0 CHECK (is_deleted IN (0,1)),
    CHECK (state = 'reserved' OR (reserved_for_student_id IS NULL AND reserved_until IS NULL))
);
CREATE UNIQUE INDEX uq_desk_label ON desks(hall_id, label) WHERE is_deleted = 0;
CREATE INDEX ix_desks_hall ON desks(hall_id);

CREATE TABLE desk_assignments (
    id         INTEGER PRIMARY KEY,
    desk_id    INTEGER NOT NULL REFERENCES desks(id) ON DELETE RESTRICT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    start_date TEXT    NOT NULL CHECK (date(start_date) IS start_date),
    end_date   TEXT    CHECK (end_date IS NULL OR date(end_date) IS end_date),
    end_reason TEXT    CHECK (end_reason IN ('released','moved','student_passive','membership_ended','desk_removed')),
    created_by INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    ended_by   INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (end_date IS NULL OR end_date >= start_date),
    CHECK ((end_date IS NULL) = (end_reason IS NULL))
);
-- Kural 3 ve 4: öğrencinin tek aktif masası, masada tek öğrenci
CREATE UNIQUE INDEX uq_desk_active ON desk_assignments(desk_id) WHERE end_date IS NULL;
CREATE UNIQUE INDEX uq_student_active_desk ON desk_assignments(student_id) WHERE end_date IS NULL;

CREATE TABLE waiting_list (
    id         INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    hall_id    INTEGER REFERENCES halls(id) ON DELETE RESTRICT,
    applied_on TEXT    NOT NULL CHECK (date(applied_on) IS applied_on),
    priority   INTEGER NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
    note       TEXT,
    status     TEXT    NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting','placed','cancelled')),
    closed_at  TEXT,
    created_by INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX uq_waiting_student ON waiting_list(student_id) WHERE status = 'waiting';
CREATE INDEX ix_waiting_hall ON waiting_list(hall_id, status);

-- ============================================================ PAKET VE ÜYELİK
CREATE TABLE packages (
    id             INTEGER PRIMARY KEY,
    name           TEXT    NOT NULL UNIQUE CHECK (length(trim(name)) > 0),
    duration_type  TEXT    NOT NULL CHECK (duration_type IN ('monthly','term','yearly','days')),
    duration_value INTEGER NOT NULL CHECK (duration_value > 0),
    price          INTEGER NOT NULL CHECK (price >= 0),
    description    TEXT,
    is_active      INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    created_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE memberships (
    id                      INTEGER PRIMARY KEY,
    student_id              INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    package_id              INTEGER NOT NULL REFERENCES packages(id) ON DELETE RESTRICT,
    package_name            TEXT    NOT NULL,
    start_date              TEXT    NOT NULL CHECK (date(start_date) IS start_date),
    base_end_date           TEXT    NOT NULL CHECK (date(base_end_date) IS base_end_date),
    end_date                TEXT    NOT NULL CHECK (date(end_date) IS end_date),
    list_price              INTEGER NOT NULL CHECK (list_price >= 0),
    discount_type           TEXT    CHECK (discount_type IN ('amount','percent')),
    discount_value          INTEGER NOT NULL DEFAULT 0 CHECK (discount_value >= 0),
    discount_amount         INTEGER NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
    sibling_discount_type   TEXT    CHECK (sibling_discount_type IN ('amount','percent')),
    sibling_discount_value  INTEGER NOT NULL DEFAULT 0 CHECK (sibling_discount_value >= 0),
    sibling_discount_amount INTEGER NOT NULL DEFAULT 0 CHECK (sibling_discount_amount >= 0),
    final_price             INTEGER NOT NULL CHECK (final_price >= 0),
    status                  TEXT    NOT NULL DEFAULT 'active' CHECK (status IN ('active','frozen','completed','cancelled')),
    cancelled_at            TEXT,
    cancel_reason           TEXT,
    created_by              INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at              TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (final_price = list_price - discount_amount - sibling_discount_amount),
    CHECK (base_end_date >= start_date),
    CHECK (end_date >= base_end_date),
    CHECK (discount_type IS NOT 'percent' OR discount_value <= 10000),
    CHECK (sibling_discount_type IS NOT 'percent' OR sibling_discount_value <= 10000),
    CHECK ((status = 'cancelled') = (cancelled_at IS NOT NULL))
);
-- Kural 2: öğrencinin aynı anda tek açık (aktif/dondurulmuş) üyeliği
CREATE UNIQUE INDEX uq_one_open_membership ON memberships(student_id) WHERE status IN ('active','frozen');
CREATE INDEX ix_memberships_end ON memberships(end_date);
CREATE INDEX ix_memberships_student ON memberships(student_id);

CREATE TRIGGER trg_memberships_no_delete BEFORE DELETE ON memberships
BEGIN SELECT RAISE(ABORT, 'Üyelik kaydı silinemez; iptal edilebilir.'); END;

CREATE TABLE membership_freezes (
    id            INTEGER PRIMARY KEY,
    membership_id INTEGER NOT NULL REFERENCES memberships(id) ON DELETE RESTRICT,
    start_date    TEXT    NOT NULL CHECK (date(start_date) IS start_date),
    end_date      TEXT    NOT NULL CHECK (date(end_date) IS end_date),
    days          INTEGER NOT NULL CHECK (days > 0),
    note          TEXT,
    status        TEXT    NOT NULL DEFAULT 'valid' CHECK (status IN ('valid','cancelled')),
    created_by    INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (end_date >= start_date),
    CHECK (days = CAST(julianday(end_date) - julianday(start_date) AS INTEGER) + 1)
);
CREATE INDEX ix_freezes_membership ON membership_freezes(membership_id);

CREATE TRIGGER trg_freeze_rules BEFORE INSERT ON membership_freezes
BEGIN
    SELECT RAISE(ABORT, 'Dondurma tarihleri mevcut bir dondurmayla çakışıyor.')
     WHERE EXISTS (SELECT 1 FROM membership_freezes f
                    WHERE f.membership_id = NEW.membership_id AND f.status = 'valid'
                      AND f.start_date <= NEW.end_date AND f.end_date >= NEW.start_date);
    SELECT RAISE(ABORT, 'Dondurma üyelik süresi içinde başlamalı.')
     WHERE NOT EXISTS (SELECT 1 FROM memberships m
                        WHERE m.id = NEW.membership_id AND NEW.start_date BETWEEN m.start_date AND m.end_date);
    SELECT RAISE(ABORT, 'Yalnız aktif ya da dondurulmuş üyelik dondurulabilir.')
     WHERE (SELECT status FROM memberships WHERE id = NEW.membership_id) NOT IN ('active','frozen');
END;
CREATE TRIGGER trg_freeze_no_delete BEFORE DELETE ON membership_freezes
BEGIN SELECT RAISE(ABORT, 'Dondurma kaydı silinemez; iptal edilebilir.'); END;
CREATE TRIGGER trg_freeze_update BEFORE UPDATE ON membership_freezes
WHEN OLD.status = 'cancelled' OR NEW.status <> 'cancelled' OR NEW.start_date <> OLD.start_date
  OR NEW.end_date <> OLD.end_date OR NEW.days <> OLD.days OR NEW.membership_id <> OLD.membership_id
BEGIN SELECT RAISE(ABORT, 'Dondurma kaydı değiştirilemez; yalnız iptal edilebilir.'); END;

-- Masa ataması kuralları (S1: aktif/dondurulmuş üyelik şart)
CREATE TRIGGER trg_desk_assign_rules BEFORE INSERT ON desk_assignments
WHEN NEW.end_date IS NULL
BEGIN
    SELECT RAISE(ABORT, 'Bu masa silinmiş ya da kullanım dışı.')
     WHERE EXISTS (SELECT 1 FROM desks d WHERE d.id = NEW.desk_id AND (d.is_deleted = 1 OR d.state = 'out_of_service'));
    SELECT RAISE(ABORT, 'Bu masa başka bir öğrenciye rezerve edilmiş.')
     WHERE EXISTS (SELECT 1 FROM desks d WHERE d.id = NEW.desk_id AND d.state = 'reserved'
                      AND d.reserved_for_student_id IS NOT NEW.student_id);
    SELECT RAISE(ABORT, 'Pasif öğrenciye masa atanamaz.')
     WHERE (SELECT status FROM students WHERE id = NEW.student_id) IS NOT 'active';
    SELECT RAISE(ABORT, 'Masa atamak için öğrencinin aktif ya da dondurulmuş üyeliği olmalı.')
     WHERE NOT EXISTS (SELECT 1 FROM memberships m WHERE m.student_id = NEW.student_id AND m.status IN ('active','frozen'));
END;
CREATE TRIGGER trg_desk_assign_no_delete BEFORE DELETE ON desk_assignments
BEGIN SELECT RAISE(ABORT, 'Masa atama geçmişi silinemez.'); END;
CREATE TRIGGER trg_desk_assign_update BEFORE UPDATE ON desk_assignments
WHEN OLD.end_date IS NOT NULL OR NEW.desk_id <> OLD.desk_id OR NEW.student_id <> OLD.student_id OR NEW.start_date <> OLD.start_date
BEGIN SELECT RAISE(ABORT, 'Masa atama geçmişi değiştirilemez; yalnız açık atama kapatılabilir.'); END;

CREATE TRIGGER trg_desk_state_occupied BEFORE UPDATE ON desks
WHEN (NEW.state = 'out_of_service' OR NEW.is_deleted = 1)
 AND EXISTS (SELECT 1 FROM desk_assignments a WHERE a.desk_id = NEW.id AND a.end_date IS NULL)
BEGIN SELECT RAISE(ABORT, 'Dolu masa kullanım dışı bırakılamaz ya da silinemez; önce masayı boşaltın.'); END;

-- S9: aktif üyeliği olan öğrenci pasife alınamaz; açık masası varsa önce boşaltılmalı
CREATE TRIGGER trg_student_passive BEFORE UPDATE OF status ON students
WHEN NEW.status = 'passive' AND OLD.status = 'active'
BEGIN
    SELECT RAISE(ABORT, 'Aktif ya da dondurulmuş üyeliği olan öğrenci pasife alınamaz.')
     WHERE EXISTS (SELECT 1 FROM memberships m WHERE m.student_id = NEW.id AND m.status IN ('active','frozen'));
    SELECT RAISE(ABORT, 'Öğrencinin açık masa ataması var; önce masayı boşaltın.')
     WHERE EXISTS (SELECT 1 FROM desk_assignments a WHERE a.student_id = NEW.id AND a.end_date IS NULL);
END;

-- ============================================================ TAKSİT, TAHSİLAT, İADE
CREATE TABLE installments (
    id            INTEGER PRIMARY KEY,
    membership_id INTEGER NOT NULL REFERENCES memberships(id) ON DELETE RESTRICT,
    no            INTEGER NOT NULL CHECK (no >= 1),
    due_date      TEXT    NOT NULL CHECK (date(due_date) IS due_date),
    amount        INTEGER NOT NULL CHECK (amount > 0),
    status        TEXT    NOT NULL DEFAULT 'open' CHECK (status IN ('open','cancelled')),
    UNIQUE (membership_id, no)
);
CREATE INDEX ix_installments_due ON installments(due_date);

CREATE TABLE payments (
    id            INTEGER PRIMARY KEY,
    receipt_no    TEXT    NOT NULL UNIQUE,
    student_id    INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    membership_id INTEGER NOT NULL REFERENCES memberships(id) ON DELETE RESTRICT,
    paid_on       TEXT    NOT NULL CHECK (date(paid_on) IS paid_on),
    amount        INTEGER NOT NULL CHECK (amount > 0),
    method        TEXT    NOT NULL CHECK (method IN ('cash','credit_card')),
    note          TEXT,
    status        TEXT    NOT NULL DEFAULT 'valid' CHECK (status IN ('valid','voided')),
    voided_at     TEXT,
    voided_by     INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    void_reason   TEXT,
    created_by    INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (status = 'valid' OR (voided_at IS NOT NULL AND length(trim(COALESCE(void_reason,''))) > 0))
);
CREATE INDEX ix_payments_paid_on ON payments(paid_on);
CREATE INDEX ix_payments_student ON payments(student_id);
CREATE INDEX ix_payments_membership ON payments(membership_id);

CREATE TRIGGER trg_payment_insert BEFORE INSERT ON payments
BEGIN
    SELECT RAISE(ABORT, 'Tahsilat, öğrencinin kendi üyeliğine bağlanmalı.')
     WHERE (SELECT student_id FROM memberships WHERE id = NEW.membership_id) IS NOT NEW.student_id;
    SELECT RAISE(ABORT, 'Yeni tahsilat iptal edilmiş olarak girilemez.') WHERE NEW.status <> 'valid';
END;
CREATE TRIGGER trg_payments_no_delete BEFORE DELETE ON payments
BEGIN SELECT RAISE(ABORT, 'Tahsilat kaydı silinemez; yalnız iptal (ters kayıt) yapılabilir.'); END;
CREATE TRIGGER trg_payments_update BEFORE UPDATE ON payments
WHEN OLD.status = 'voided' OR NEW.status <> 'voided' OR NEW.amount <> OLD.amount OR NEW.method <> OLD.method
  OR NEW.paid_on <> OLD.paid_on OR NEW.student_id <> OLD.student_id OR NEW.membership_id <> OLD.membership_id
  OR NEW.receipt_no <> OLD.receipt_no
BEGIN SELECT RAISE(ABORT, 'Tahsilat kaydı değiştirilemez; yalnız iptal (ters kayıt) yapılabilir.'); END;
CREATE TRIGGER trg_payments_void_refunded BEFORE UPDATE OF status ON payments
WHEN NEW.status = 'voided' AND EXISTS (SELECT 1 FROM refunds r WHERE r.payment_id = NEW.id)
BEGIN SELECT RAISE(ABORT, 'İadesi yapılmış tahsilat iptal edilemez.'); END;

CREATE TABLE payment_allocations (
    id             INTEGER PRIMARY KEY,
    payment_id     INTEGER NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
    installment_id INTEGER NOT NULL REFERENCES installments(id) ON DELETE RESTRICT,
    amount         INTEGER NOT NULL CHECK (amount > 0),
    UNIQUE (payment_id, installment_id)
);
CREATE INDEX ix_alloc_installment ON payment_allocations(installment_id);

CREATE TABLE refunds (
    id          INTEGER PRIMARY KEY,
    payment_id  INTEGER NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
    refunded_on TEXT    NOT NULL CHECK (date(refunded_on) IS refunded_on),
    amount      INTEGER NOT NULL CHECK (amount > 0),
    method      TEXT    NOT NULL CHECK (method IN ('cash','credit_card')),
    action      TEXT    NOT NULL CHECK (action IN ('cancel_membership','amount_only')),
    reason      TEXT    NOT NULL CHECK (length(trim(reason)) > 0),
    created_by  INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_refunds_payment ON refunds(payment_id);
CREATE INDEX ix_refunds_date ON refunds(refunded_on);

CREATE TABLE refund_allocations (
    id             INTEGER PRIMARY KEY,
    refund_id      INTEGER NOT NULL REFERENCES refunds(id) ON DELETE RESTRICT,
    installment_id INTEGER NOT NULL REFERENCES installments(id) ON DELETE RESTRICT,
    amount         INTEGER NOT NULL CHECK (amount > 0),
    UNIQUE (refund_id, installment_id)
);
CREATE INDEX ix_refund_alloc_installment ON refund_allocations(installment_id);

-- Taksitin ödenen tutarı: geçerli tahsilat dağılımları − iade dağılımları (saklanmaz, hesaplanır)
CREATE VIEW v_installment_balance AS
SELECT i.id AS installment_id, i.membership_id, i.no, i.due_date, i.amount, i.status,
       COALESCE((SELECT SUM(a.amount) FROM payment_allocations a JOIN payments p ON p.id = a.payment_id
                  WHERE a.installment_id = i.id AND p.status = 'valid'), 0)
     - COALESCE((SELECT SUM(r.amount) FROM refund_allocations r WHERE r.installment_id = i.id), 0) AS paid
  FROM installments i;

-- Kural 7: taksit ödemeleri taksit tutarını aşamaz
CREATE TRIGGER trg_alloc_rules BEFORE INSERT ON payment_allocations
BEGIN
    SELECT RAISE(ABORT, 'İptal edilmiş tahsilata dağıtım yapılamaz.')
     WHERE (SELECT status FROM payments WHERE id = NEW.payment_id) IS NOT 'valid';
    SELECT RAISE(ABORT, 'Taksit, tahsilatın bağlı olduğu üyeliğe ait değil.')
     WHERE (SELECT membership_id FROM installments WHERE id = NEW.installment_id)
        IS NOT (SELECT membership_id FROM payments WHERE id = NEW.payment_id);
    SELECT RAISE(ABORT, 'İptal edilmiş taksite ödeme yapılamaz.')
     WHERE (SELECT status FROM installments WHERE id = NEW.installment_id) = 'cancelled';
    SELECT RAISE(ABORT, 'Fazla ödeme: tutar taksitin kalan borcunu aşıyor.')
     WHERE (SELECT paid FROM v_installment_balance WHERE installment_id = NEW.installment_id) + NEW.amount
         > (SELECT amount FROM installments WHERE id = NEW.installment_id);
    SELECT RAISE(ABORT, 'Dağıtılan tutar tahsilat tutarını aşıyor.')
     WHERE (SELECT COALESCE(SUM(amount), 0) FROM payment_allocations WHERE payment_id = NEW.payment_id) + NEW.amount
         > (SELECT amount FROM payments WHERE id = NEW.payment_id);
END;
CREATE TRIGGER trg_alloc_no_update BEFORE UPDATE ON payment_allocations
BEGIN SELECT RAISE(ABORT, 'Tahsilat dağılımı değiştirilemez.'); END;
CREATE TRIGGER trg_alloc_no_delete BEFORE DELETE ON payment_allocations
BEGIN SELECT RAISE(ABORT, 'Tahsilat dağılımı silinemez.'); END;

CREATE TRIGGER trg_installment_amount BEFORE UPDATE OF amount ON installments
WHEN NEW.amount < (SELECT paid FROM v_installment_balance WHERE installment_id = OLD.id)
BEGIN SELECT RAISE(ABORT, 'Taksit tutarı ödenmiş tutarın altına düşürülemez.'); END;
CREATE TRIGGER trg_installment_membership BEFORE UPDATE OF membership_id ON installments
WHEN NEW.membership_id <> OLD.membership_id
BEGIN SELECT RAISE(ABORT, 'Taksit başka üyeliğe taşınamaz.'); END;

-- Kural 8: iade, tahsilatın iade edilebilir tutarını aşamaz
CREATE TRIGGER trg_refund_rules BEFORE INSERT ON refunds
BEGIN
    SELECT RAISE(ABORT, 'İptal edilmiş tahsilat için iade yapılamaz.')
     WHERE (SELECT status FROM payments WHERE id = NEW.payment_id) IS NOT 'valid';
    SELECT RAISE(ABORT, 'İade tutarı tahsilatın iade edilebilir tutarını aşıyor.')
     WHERE (SELECT COALESCE(SUM(amount), 0) FROM refunds WHERE payment_id = NEW.payment_id) + NEW.amount
         > (SELECT amount FROM payments WHERE id = NEW.payment_id);
END;
CREATE TRIGGER trg_refunds_no_update BEFORE UPDATE ON refunds
BEGIN SELECT RAISE(ABORT, 'İade kaydı değiştirilemez.'); END;
CREATE TRIGGER trg_refunds_no_delete BEFORE DELETE ON refunds
BEGIN SELECT RAISE(ABORT, 'İade kaydı silinemez.'); END;

CREATE TRIGGER trg_refund_alloc_rules BEFORE INSERT ON refund_allocations
BEGIN
    SELECT RAISE(ABORT, 'İade dağılımı, tahsilatın bu taksite ödediği tutarı aşıyor.')
     WHERE COALESCE((SELECT a.amount FROM payment_allocations a JOIN refunds r ON r.payment_id = a.payment_id
                      WHERE r.id = NEW.refund_id AND a.installment_id = NEW.installment_id), 0)
         - COALESCE((SELECT SUM(ra.amount) FROM refund_allocations ra JOIN refunds r2 ON r2.id = ra.refund_id
                      WHERE ra.installment_id = NEW.installment_id
                        AND r2.payment_id = (SELECT payment_id FROM refunds WHERE id = NEW.refund_id)), 0)
         < NEW.amount;
    SELECT RAISE(ABORT, 'İade dağılımı iade tutarını aşıyor.')
     WHERE (SELECT COALESCE(SUM(amount), 0) FROM refund_allocations WHERE refund_id = NEW.refund_id) + NEW.amount
         > (SELECT amount FROM refunds WHERE id = NEW.refund_id);
END;
CREATE TRIGGER trg_refund_alloc_no_update BEFORE UPDATE ON refund_allocations
BEGIN SELECT RAISE(ABORT, 'İade dağılımı değiştirilemez.'); END;
CREATE TRIGGER trg_refund_alloc_no_delete BEFORE DELETE ON refund_allocations
BEGIN SELECT RAISE(ABORT, 'İade dağılımı silinemez.'); END;

-- ============================================================ GİDER VE KANTİN
CREATE TABLE expenses (
    id          INTEGER PRIMARY KEY,
    hall_id     INTEGER REFERENCES halls(id) ON DELETE RESTRICT,
    category    TEXT    NOT NULL CHECK (category IN ('rent','electricity','water','internet','staff','other')),
    amount      INTEGER NOT NULL CHECK (amount > 0),
    spent_on    TEXT    NOT NULL CHECK (date(spent_on) IS spent_on),
    note        TEXT,
    status      TEXT    NOT NULL DEFAULT 'valid' CHECK (status IN ('valid','voided')),
    voided_at   TEXT,
    voided_by   INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    void_reason TEXT,
    created_by  INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (status = 'valid' OR (voided_at IS NOT NULL AND length(trim(COALESCE(void_reason,''))) > 0))
);
CREATE INDEX ix_expenses_date ON expenses(spent_on);

CREATE TRIGGER trg_expenses_no_delete BEFORE DELETE ON expenses
BEGIN SELECT RAISE(ABORT, 'Gider kaydı silinemez; iptal edilebilir.'); END;
CREATE TRIGGER trg_expenses_update BEFORE UPDATE ON expenses
WHEN OLD.status = 'voided' OR NEW.status <> 'voided' OR NEW.amount <> OLD.amount OR NEW.spent_on <> OLD.spent_on
  OR NEW.category <> OLD.category OR NEW.hall_id IS NOT OLD.hall_id
BEGIN SELECT RAISE(ABORT, 'Gider kaydı değiştirilemez; iptal edip yeniden girin.'); END;

CREATE TABLE canteen_income (
    id          INTEGER PRIMARY KEY,
    year        INTEGER NOT NULL CHECK (year BETWEEN 2000 AND 2100),
    month       INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
    amount      INTEGER NOT NULL CHECK (amount >= 0),
    note        TEXT,
    status      TEXT    NOT NULL DEFAULT 'valid' CHECK (status IN ('valid','voided')),
    voided_at   TEXT,
    voided_by   INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    void_reason TEXT,
    replaced_by INTEGER REFERENCES canteen_income(id) ON DELETE RESTRICT,
    created_by  INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    CHECK (status = 'valid' OR (voided_at IS NOT NULL AND length(trim(COALESCE(void_reason,''))) > 0))
);
-- Kural 5: bir aya tek geçerli kantin kaydı
CREATE UNIQUE INDEX uq_canteen_month ON canteen_income(year, month) WHERE status = 'valid';

CREATE TRIGGER trg_canteen_no_delete BEFORE DELETE ON canteen_income
BEGIN SELECT RAISE(ABORT, 'Kantin kaydı silinemez; iptal edilebilir.'); END;
CREATE TRIGGER trg_canteen_update BEFORE UPDATE ON canteen_income
WHEN NEW.status <> 'voided' OR NEW.amount <> OLD.amount OR NEW.year <> OLD.year OR NEW.month <> OLD.month
  OR NEW.replaced_by IS NOT NULL AND NEW.replaced_by = OLD.id
  OR (OLD.status = 'voided' AND NOT (OLD.replaced_by IS NULL AND NEW.replaced_by IS NOT NULL
      AND NEW.voided_at IS OLD.voided_at AND NEW.void_reason IS OLD.void_reason AND NEW.voided_by IS OLD.voided_by))
BEGIN SELECT RAISE(ABORT, 'Kantin kaydı değiştirilemez; düzeltme iptal + yeni kayıtla yapılır.'); END;

-- ============================================================ KASA DEFTERİ (raporların TEK kaynağı)
CREATE TABLE cash_movements (
    id           INTEGER PRIMARY KEY,
    occurred_on  TEXT    NOT NULL CHECK (date(occurred_on) IS occurred_on),
    direction    TEXT    NOT NULL CHECK (direction IN ('in','out')),
    amount       INTEGER NOT NULL CHECK (amount > 0),
    kind         TEXT    NOT NULL CHECK (kind IN ('payment','payment_void','refund','expense','expense_void','canteen','canteen_void')),
    method       TEXT    CHECK (method IN ('cash','credit_card')),
    source_table TEXT    NOT NULL,
    source_id    INTEGER NOT NULL,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    -- Kural 11: aynı kaynak aynı türde ikinci kasa hareketi oluşturamaz
    UNIQUE (kind, source_table, source_id),
    CHECK (
        (kind = 'payment'      AND direction = 'in'  AND source_table = 'payments'       AND method IS NOT NULL) OR
        (kind = 'payment_void' AND direction = 'out' AND source_table = 'payments'       AND method IS NOT NULL) OR
        (kind = 'refund'       AND direction = 'out' AND source_table = 'refunds'        AND method IS NOT NULL) OR
        (kind = 'expense'      AND direction = 'out' AND source_table = 'expenses'       AND method IS NULL) OR
        (kind = 'expense_void' AND direction = 'in'  AND source_table = 'expenses'       AND method IS NULL) OR
        (kind = 'canteen'      AND direction = 'in'  AND source_table = 'canteen_income' AND method IS NULL) OR
        (kind = 'canteen_void' AND direction = 'out' AND source_table = 'canteen_income' AND method IS NULL)
    )
);
CREATE INDEX ix_cash_date ON cash_movements(occurred_on);

-- Kasa hareketi kaynak kaydıyla birebir tutmalı (tutar, yöntem, durum)
CREATE TRIGGER trg_cash_source BEFORE INSERT ON cash_movements
BEGIN
    SELECT RAISE(ABORT, 'Kasa hareketi tahsilat kaydıyla uyuşmuyor.')
     WHERE NEW.kind = 'payment' AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.id = NEW.source_id
             AND p.status = 'valid' AND p.amount = NEW.amount AND p.method = NEW.method AND p.paid_on = NEW.occurred_on);
    SELECT RAISE(ABORT, 'Ters kasa hareketi iptal edilmiş tahsilatla uyuşmuyor.')
     WHERE NEW.kind = 'payment_void' AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.id = NEW.source_id
             AND p.status = 'voided' AND p.amount = NEW.amount AND p.method = NEW.method);
    SELECT RAISE(ABORT, 'Kasa hareketi iade kaydıyla uyuşmuyor.')
     WHERE NEW.kind = 'refund' AND NOT EXISTS (SELECT 1 FROM refunds r WHERE r.id = NEW.source_id
             AND r.amount = NEW.amount AND r.method = NEW.method AND r.refunded_on = NEW.occurred_on);
    SELECT RAISE(ABORT, 'Kasa hareketi gider kaydıyla uyuşmuyor.')
     WHERE NEW.kind = 'expense' AND NOT EXISTS (SELECT 1 FROM expenses e WHERE e.id = NEW.source_id
             AND e.status = 'valid' AND e.amount = NEW.amount AND e.spent_on = NEW.occurred_on);
    SELECT RAISE(ABORT, 'Ters kasa hareketi iptal edilmiş giderle uyuşmuyor.')
     WHERE NEW.kind = 'expense_void' AND NOT EXISTS (SELECT 1 FROM expenses e WHERE e.id = NEW.source_id
             AND e.status = 'voided' AND e.amount = NEW.amount);
    SELECT RAISE(ABORT, 'Kasa hareketi kantin kaydıyla uyuşmuyor.')
     WHERE NEW.kind = 'canteen' AND NOT EXISTS (SELECT 1 FROM canteen_income c WHERE c.id = NEW.source_id
             AND c.status = 'valid' AND c.amount = NEW.amount);
    SELECT RAISE(ABORT, 'Ters kasa hareketi iptal edilmiş kantin kaydıyla uyuşmuyor.')
     WHERE NEW.kind = 'canteen_void' AND NOT EXISTS (SELECT 1 FROM canteen_income c WHERE c.id = NEW.source_id
             AND c.status = 'voided' AND c.amount = NEW.amount);
END;
CREATE TRIGGER trg_cash_no_update BEFORE UPDATE ON cash_movements
BEGIN SELECT RAISE(ABORT, 'Kasa hareketi değiştirilemez.'); END;
CREATE TRIGGER trg_cash_no_delete BEFORE DELETE ON cash_movements
BEGIN SELECT RAISE(ABORT, 'Kasa hareketi silinemez.'); END;

-- ============================================================ SMS VE BELGELER
CREATE TABLE sms_templates (
    id        INTEGER PRIMARY KEY,
    name      TEXT    NOT NULL UNIQUE CHECK (length(trim(name)) > 0),
    body      TEXT    NOT NULL CHECK (length(trim(body)) > 0),
    kind      TEXT    NOT NULL CHECK (kind IN ('overdue','expiry','general')),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE sms_logs (
    id                  INTEGER PRIMARY KEY,
    batch_id            TEXT,
    student_id          INTEGER REFERENCES students(id) ON DELETE RESTRICT,
    phone               TEXT    NOT NULL,
    message             TEXT    NOT NULL,
    template_id         INTEGER REFERENCES sms_templates(id) ON DELETE RESTRICT,
    sent_at             TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    sent_by             INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    provider_msg_id     TEXT,
    result              TEXT    NOT NULL CHECK (result IN ('accepted','failed','test')),
    delivery_status     TEXT,
    delivery_checked_at TEXT,
    error               TEXT
);
CREATE INDEX ix_sms_sent ON sms_logs(sent_at);
CREATE INDEX ix_sms_student ON sms_logs(student_id);

CREATE TABLE document_records (
    id            INTEGER PRIMARY KEY,
    doc_type      TEXT    NOT NULL CHECK (doc_type IN ('receipt_a4','receipt_thermal','contract','report')),
    doc_no        TEXT,
    student_id    INTEGER REFERENCES students(id) ON DELETE RESTRICT,
    payment_id    INTEGER REFERENCES payments(id) ON DELETE RESTRICT,
    membership_id INTEGER REFERENCES memberships(id) ON DELETE RESTRICT,
    file_path     TEXT    NOT NULL,
    created_by    INTEGER REFERENCES users(id) ON DELETE RESTRICT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_docs_student ON document_records(student_id);

-- ============================================================ SİSTEM
CREATE TABLE settings (
    key       TEXT PRIMARY KEY,
    value     TEXT,
    is_secret INTEGER NOT NULL DEFAULT 0 CHECK (is_secret IN (0,1))
);

CREATE TABLE doc_counters (
    series  TEXT    NOT NULL CHECK (series IN ('M','S','OGR')),
    year    INTEGER NOT NULL CHECK (year BETWEEN 2000 AND 2100),
    last_no INTEGER NOT NULL DEFAULT 0 CHECK (last_no >= 0),
    PRIMARY KEY (series, year)
);

CREATE TABLE backup_logs (
    id         INTEGER PRIMARY KEY,
    kind       TEXT    NOT NULL CHECK (kind IN ('auto','manual','pre_restore','pre_migration','restore')),
    file_path  TEXT,
    size_bytes INTEGER,
    integrity  TEXT,
    ok         INTEGER NOT NULL CHECK (ok IN (0,1)),
    message    TEXT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
